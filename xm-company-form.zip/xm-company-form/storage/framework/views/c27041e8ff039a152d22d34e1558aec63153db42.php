<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>XM PHP Exercise</title>
   <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>">
   <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
   <script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
   <script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
   <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
</head><?php /**PATH D:\Xampp\htdocs\xm-company-form\resources\views/_head.blade.php ENDPATH**/ ?>