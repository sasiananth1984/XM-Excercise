<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">XM PHP Exercise</a>
    </div>
</nav><?php /**PATH D:\Xampp\htdocs\xm-company-form\resources\views/_header.blade.php ENDPATH**/ ?>