<?php echo $__env->make('_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container full-width">
        <div class="row">
            <div class="column left">
                <h2>Show Chart</h2>
            </div>
            <div class="column right">
                <h2><a href="<?php echo e(url('/company')); ?>">Show Table</a></h2>
            </div>
        </div>
        <canvas id="myChart"></canvas>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                var labels = <?php echo json_encode($labels, 15, 512) ?>;
                var highValues = <?php echo json_encode($highValues, 15, 512) ?>;
                var lowValues = <?php echo json_encode($lowValues, 15, 512) ?>;
                var ctx = document.getElementById('myChart').getContext('2d');
                var myChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'High Values',
                            data: highValues,
                            borderColor: 'red',
                            borderWidth: 1,
                            fill: false
                        }, {
                            label: 'Low Values',
                            data: lowValues,
                            borderColor: 'blue',
                            borderWidth: 1,
                            fill: false
                        }]
                    }
                });
            });
        </script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html><?php /**PATH D:\Xampp\htdocs\xm-company-form\resources\views/chart/index.blade.php ENDPATH**/ ?>