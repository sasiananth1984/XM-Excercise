<?php echo $__env->make('_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
   <?php echo $__env->make('_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <!-- Page content-->
   <div class="container">
      <div class="text-center mt-5">
         <h1>Get Historical Data</h1> 
         <p>( Ex : Select AAPL for Test Data)</p>
      </div>
      <form method="post" action="<?php echo e(URL::to('/company')); ?>" id="companyForm">
         <!-- CROSS Site Request Forgery Protection -->
         <?php echo csrf_field(); ?>
         <div class="form-group">
            <label>Company symbol</label>
            <select name="symbol" class="form-control" id="symbol">
               <?php $__currentLoopData = $symbols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $syms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($syms); ?>"><?php echo e($syms); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
         </div>
         <div class="form-group">
            <label>Email</label>
            <input type="email" class="form-control" name="email" id="email" required>
         </div>
         <div class="form-group">
            <label class="col-xs-3 control-label">Start date</label>
            <div class="col-xs-5">
               <input type="text" class="form-control" name="start_date" id="start_date" required />
            </div>
         </div>
         <div class="form-group">
            <label class="col-xs-3 control-label">End date</label>
            <div class="col-xs-5">
               <input type="text" class="form-control" name="end_date" id="end_date" required />
            </div>
         </div>
         <div class="form-group display-hide">
            <label>Message</label>
            <textarea class="form-control hide" name="message" id="message" rows="4" required></textarea>
         </div>
         <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
         <input type="submit" name="send" value="Submit" class="btn btn-dark btn-block">
      </form>
      
   </div>
</body>

</html><?php /**PATH D:\Xampp\htdocs\xm-company-form\resources\views/company.blade.php ENDPATH**/ ?>