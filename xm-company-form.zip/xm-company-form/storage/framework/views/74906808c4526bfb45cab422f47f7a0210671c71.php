<?php echo $__env->make('_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
  <?php echo $__env->make('_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="container full-width">
    <div class="row">
      <div class="column left">
        <h2>Show Data</h2>
      </div>
      <div class="column right">
        <h2><a href="<?php echo e(url('/company')); ?>">Go Back</a></h2>
      </div>
    </div>
    <section class="intro row">
      <table id="records" class="table table-bordered table-striped">
        <tr>
          <th>Date</th>
          <th>open</th>
          <th>high</th>
          <th>low</th>
          <th>close</th>
          <th>volume</th>
        </tr>
        <tr>
          <td colspan="6">NO Data</td>
        </tr>
      </table>
    </section>
</body>
</html><?php /**PATH D:\Xampp\htdocs\xm-company-form\resources\views/nodataview.blade.php ENDPATH**/ ?>