<p>Subject: {{ $companyName }}</p>
<p>Body: From {{ $startDate }} to {{ $endDate }}</p>